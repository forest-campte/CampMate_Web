
package com.example.campmate

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class CampMateApp : Application()