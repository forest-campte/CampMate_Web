package com.Campmate.DYCampmate.repository;


import com.Campmate.DYCampmate.entity.ChecklistCategoryEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ChecklistCategoryRepo extends JpaRepository<ChecklistCategoryEntity, Long> {

}
